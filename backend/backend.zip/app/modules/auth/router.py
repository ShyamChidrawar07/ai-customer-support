"""TODO: authentication HTTP endpoints."""
